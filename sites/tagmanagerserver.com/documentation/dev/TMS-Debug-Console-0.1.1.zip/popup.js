function Init(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var activeTab = tabs[0].id;

        let link = document.createElement('a');
        link.href = tabs[0].url;
        var tms_hostName = link.protocol+'//'+link.host;
        document.getElementById("tms_host").innerText = link.host;
        
        chrome.tabs.sendMessage(activeTab, {action:"getSetting"}, function(response){
            if(typeof response !== 'undefined' && response.hasOwnProperty('sAuth')){
                document.getElementById("tms_debug_auth").value = response.sAuth;
                document.getElementById("tms_debug_preview").value = response.sPreview;

                if(response.sConsole == 1){
                    document.getElementById("tms_debug_console").checked = true;
                }
                if(response.sMode == 1){
                    document.getElementById("tms_debug_mode").checked = true;
                }
            }else{

            }
            
        });
    });
    RenderInfo();
    document.getElementById("tms_save").addEventListener("click", SaveInfo);
}

function RenderInfo(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var activeTab = tabs[0].id;
        chrome.tabs.sendMessage(activeTab, {action:"getSetting"}, function(response){
            if(response.sConsole == 1){

                document.getElementById("intro").style.display = "none";
                document.getElementById("intro_active").style.display = "block";

                var info_text = 'Active Debug Console with valid debugAuth code';
                var sColor = '#49a32f';

                if(response.sError != 0){
                    sColor = '#ff0000';
                    if(response.sError == 'auth'){
                        info_text = 'invalid debugAuth code';
                    }else{
                        info_text = 'TMS error';
                    }
                }else if(response.bPreviewValid == 1){
                    sColor = '#9c26b0';
                    info_text = 'debug and preview mode';
                    if(response.bPreviewValid == 0){
                        info_text = 'debug mode';
                    }else if(response.sMode == 0){
                        info_text = 'preview mode';
                    }
                }else if(response.sMode == 1){
                    sColor = '#e47725';
                    info_text = 'debug mode';
                }
                document.getElementById("intro_active_info").innerText = info_text;
                document.getElementById("intro_active_info").style.color = sColor;

                var elements = document.querySelectorAll('.info_color_bg');
                for(var i = 0 ; i < elements.length ; i++) {
                    elements[i].style.background = sColor;
                }

                document.getElementById("info_push_count").innerText = response.iPushCount;
                document.getElementById("info_tag_count").innerText = response.iTagCount;

            }else{
                document.getElementById("intro_active").style.display = "none";
                document.getElementById("intro").style.display = "block";
            }
        });
    });
}

function SaveInfo(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var activeTab = tabs[0].id;
        var oSetting = {};
        oSetting.sAuth = document.getElementById("tms_debug_auth").value; 
        oSetting.sConsole = (document.getElementById("tms_debug_console").checked ? 1 : 0);
        oSetting.sMode = (document.getElementById("tms_debug_mode").checked ? 1 : 0);
        oSetting.sPreview = document.getElementById("tms_debug_preview").value;

        chrome.tabs.sendMessage(activeTab, {action:"saveSetting", data:oSetting}, function(response){
            document.getElementById("tms_save_info").style.display = 'inline-block';
            document.getElementById("tms_save_info").innerText = response;
            setTimeout(function(){
                document.getElementById("tms_save_info").style.display = 'none';
                RenderInfo();
            }, 2000);

            RenderInfo();
        });
    });
}

window.onload=Init;
