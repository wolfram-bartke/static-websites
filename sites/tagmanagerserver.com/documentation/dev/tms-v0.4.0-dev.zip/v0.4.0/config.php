<?php

$aConfig = array();

// Your account credentials 
$aConfig['default']['email'] = 'beta@tagmanagerserver.com';                 // Only for beta testing on a development server!
$aConfig['default']['key'] = 'b5c74fef6ce04f6ec289403fcvu3Wbzvx4Q61cuzg2';  // Only for beta testing on a development server!

// default TMS configuration
$aConfig['default']['cookieHost'] = 'your-domain.com';          // your-domain.com
$aConfig['default']['cookieName'] = '_tms';                     // Name of your TMS clientID cookie 
$aConfig['default']['gtmContainerFile'] = 'GTM-Container/GTM-TEST.json';
$aConfig['default']['debugAuth'] = '[CHANGE-THIS-AUTH-CODE]';   // debug auth code for Google Chrome Extension: TMS Debug Console
$aConfig['default']['debugConsole'] = 1;                        // better delete this line and use the TMS Debug Console: https://chrome.google.com/webstore/detail/tag-manager-server-debug/camhbggldedhfjbjabcndiggmpfghkdp
#$aConfig['default']['overWriteUserIP'] = '0.0.0.0';            // overwrite user IP address before sending to Google Analytics

// Example configuration for a multidomain setup with different parameters per hostname
# $aConfig['www.tagmanagerserver.com']['cookieHost'] = 'tagmanagerserver.com';
# $aConfig['www.tagmanagerserver.com']['gtmContainerFile'] = 'GTM-Container/www_tms_com.json';
# $aConfig['blog.tagmanagerserver.com']['cookieHost'] = 'tagmanagerserver.com';
# $aConfig['blog.tagmanagerserver.com']['gtmContainerFile'] = 'GTM-Container/blog_tms_com.json';

// Example configuration settings for localhost 
$aConfig['localhost']['cookieHost'] = 'localhost';
$aConfig['localhost']['gtmContainerFile'] = 'GTM-Container/GTM-TEST.json';
$aConfig['localhost']['email'] = 'beta@tagmanagerserver.com';
$aConfig['localhost']['key'] = 'b5c74fef6ce04f6ec289403fcvu3Wbzvx4Q61cuzg2';

return $aConfig;

?>