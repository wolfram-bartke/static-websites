# Changelog

All notable changes to this project will be documented in this file.

## v0.3.5 - ??.??.2020
- debug auth inkl. GTM-Preview file
- delete debug html codes
- license server
- mute dataLayer push events
- add integrated GTM URL Variables

### Changed
- Variablen inkl. lookup tables funktionieren jetzt besser mit true und false werten

## v0.3.4 - 07.05.2020

### Added
- Changelog
- blocking triggers are now handled for tags
- debug hint for non valid Google Tag Manager export JSON-file

### Changed
- debug improvements
  - print event name in browser console.log output
- configuration improvements

### Removed
- Possibility to overwrite the TMS configuration via the api.php file


## v0.3.3 - 26.04.2020

### Changed
- Check availability of curl module before executing and print this as debug hint


## v0.3.2 - 22.04.2020

### Changed
- TMS configuration moved to a config.php file to simplify settings and updates
- GTM-JSON Container moved to subfolder 'GTM-Container' incl. htaccess file to prevent external access
- debugging improvements


## v0.3.1 - 22.04.2020

### Changed
- Improved troubleshooting and configuration guide.