<?php

$sDemoGTM_ID = 'GTM-MXCK8WQ';
#$sDemoGTM_ID = 'GTM-XXXXXXX'; // The GTM-ID of your Google Tag Manager Container where you imported the GTM-TEST.json File

$sTMS_ScriptURL = 'tms-test.js';
#$sTMS_ScriptURL = 'tms-proxy/tms.js';

$sExamplePage = (empty($_GET['example'])) ? 'homepage' : $_GET['example'];

$aExamples = array();
$aExamples['homepage']['name'] = 'Homepage';
$aExamples['homepage']['dataLayer'][] = (object) [
  'pageType' => 'homepage',
  'visitorType' => 'external',
];
$aExamples['content']['name'] = 'Content Page';
$aExamples['content']['dataLayer'][] = (object) [
  'pageType' => 'content',
  'visitorType' => 'external',
];
$aExamples['contact']['name'] = 'Contact &amp; Conversion';
$aExamples['contact']['dataLayer'][] = (object) [
  'pageType' => 'contact',
  'visitorType' => 'external',
];
$aExamples['contact']['dataLayer'][] = (object) [
  'event' => 'uaData',
  'eventCategory' => 'conversion',
  'eventAction' => 'form.sent',
  'eventLabel' => 'Conversion ID:'.time(),
];
$aExamples['product.detail']['name'] = 'EEC Product Detail + AddToCart';
$aExamples['product.detail']['dataLayer'][] = (object) [
  'pageType' => 'product.detail',
  'visitorType' => 'external',
  'ecommerce' => (object) [
    'detail' => (object) [
      'actionField' => (object) [
        'list' => 'demo'
      ],
      'products' => array (
        0 => (object) [
          'id' => 'Tag Manager Server',
          'price' => '99.99',
          'brand' => 'HOKATA',
          'category' => 'server-based tracking',
          'variant' => 'v0.3',
        ],
      ),
    ]
  ]
];
$aExamples['product.detail']['dataLayer'][] = (object) [
  'event' => 'uaData',
  'eventCategory' => 'ecommerce',
  'eventAction' => 'addToCart',
  'ecommerce' => (object) [
    'add' => (object) [
      'actionField' => (object) [
        'list' => 'demo'
      ],
      'products' => array (
        0 => (object) [
          'id' => 'Tag Manager Server',
          'price' => '99.99',
          'brand' => 'HOKATA',
          'category' => 'server-based tracking',
          'variant' => 'v0.3',
          'quantity' => '1',
        ],
      ),
    ]
  ]
];
$aExamples['checkout.success']['name'] = 'EEC Checkout Success';
$aExamples['checkout.success']['dataLayer'][] = (object) [
  'pageType' => 'checkout.success',
  'visitorType' => 'external',
  'ecommerce' => (object) [
    'purchase' => (object) [
      'actionField' => (object) [
        'id' => time(),
        'revenue' => '99.99',
        'tax' => '19.00',
        'shipping' => '4.99',
        'coupon' => 'DOWNLOAD_123',
      ],
      'products' => array (
        0 => (object) [
          'id' => 'Tag Manager Server',
          'price' => '99.99',
          'brand' => 'HOKATA',
          'category' => 'server-based tracking',
          'variant' => 'v0.3',
        ],
      ),
    ]
  ]
];

$aDemoButtonHTML = [];
$aDataLayerHTML = [];
$aDataLayerHTML[] = 'window.dataLayer = window.dataLayer || [];';
foreach($aExamples as $sExample => $aExampleData){
  $sActiveClass = ($sExamplePage == $sExample) ? 'mdl-button--cta' : '';
  $aDemoButtonHTML[] = '<a href="?example='.$sExample.'" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect '.$sActiveClass.'">'.$aExampleData['name'].'</a>';
  if(!empty($sActiveClass)){
    foreach($aExampleData['dataLayer'] as $aData){
      $aDataLayerHTML[] = 'window.dataLayer.push('.json_encode($aData, JSON_PRETTY_PRINT).');';
    }  
  }
}
$sDataLayerHTML = implode($aDataLayerHTML, "\n");

?><!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Server-side tracking Demo with Tag Manager Server. Check this Google Analytics tracking with all browsers (ITP & ETP) and blockers (AdBlock, Ghostery, ...).">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Tag Manager Server Demo to Check this with all browsers (ITP & ETP) and blockers (AdBlock, Ghostery, ...) - Open Source</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.grey-blue.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="tms.css?v=1" />

    <script>
    var sTMSRequest = '';
    function RenderGaRequest(sHitUrl, sTargetID){
      if(element = document.getElementById(sTargetID)){
        if(sTargetID == 'hit_tms'){
          document.getElementById("GTM_TMS").classList.remove("block");
          document.getElementById("GTM_TMS").classList.add("success");
          document.getElementById("GTM_TMS").innerText = 'done';
          if(sHitUrl != ''){
            oUrlParams = JSON.parse(sHitUrl);
            if(oUrlParams['ga-request']){
              aUrlParams = [];
              for(sVar in oUrlParams['ga-request'][0]){
                aUrlParams.push(sVar+"="+oUrlParams['ga-request'][0][sVar]);
              }
              element.innerText = element.innerText + decodeURIComponent(aUrlParams.join("&")) + "\n\n" + decodeURIComponent(aUrlParams.join("\n")) + "\n\n\n";
            }
            document.getElementById("GA_TMS").classList.remove("block");
            document.getElementById("GA_TMS").classList.add("success");
            document.getElementById("GA_TMS").innerText = 'done';
          }
        }
        if(sTargetID == 'hit_ga_gtm'){
          element.innerText = element.innerText + decodeURIComponent(sHitUrl) + "\n\n" + decodeURIComponent(sHitUrl.split('&').join("\n")) + "\n";
          document.getElementById("GA_done").classList.remove("block");
          document.getElementById("GA_done").classList.add("success");
          document.getElementById("GA_done").innerText = 'done';
        }
        
      }
    }
    </script>
    <script src="<?php print $sTMS_ScriptURL ?>"></script>
    <script>
<?php print array_shift($aDataLayerHTML); ?>
<?php print array_shift($aDataLayerHTML); ?>
    </script>
    
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?php print $sDemoGTM_ID;?>');</script>
<!-- End Google Tag Manager -->
<?php print '<script>'.implode("\n", $aDataLayerHTML).'</script>'; ?>
<body>
<div class="mdl-layout mdl-js-layout">

  
<main class="mdl-layout__content">


<div class="mdl-grid section-content">

  <div class="mdl-cell mdl-cell--12-col">
    


    <div class="mdl-card__title">
      <h1 class="mdl-card__title-text">Tag Manager Server Demo: <br>Google Analytics + Google Tag Manager vs. Tag Manager Server</h1>
    </div>
  </div> <!-- end mdl-grid section-content -->

  <div class="mdl-cell mdl-cell--12-col">
    <div class="mdl-card__supporting-text">
      <h2 style="padding-left:0;">Page Examples</h2>
      <p>
        Open different Browser and check this Analytics tracking methods with different browser settings like ITP or ETP and activate common blockers like AdBlock or Ghostery.
      </p>
<?php
print implode(' &nbsp; ', $aDemoButtonHTML);
?>
     </div>

      <h2>DataLayer Data for active Page Example</h2>
      <pre style="margin:0 20px 20px 20px;padding:20px;background-color:#ebebeb;">
<?php
print $sDataLayerHTML;
?>
      </pre>
    </div>

  </div> <!-- end mdl-grid section-content -->


	<div class="mdl-grid section-content" style="background-color:#ebebeb">
			
			
			  <div class="mdl-cell mdl-cell--12-col">
          <h2>Tracking Request Results</h2>
          <p style="padding-left:20px;"><small>
            <b>Your User-Agent</b>: <?php print $_SERVER['HTTP_USER_AGENT'] ?>
          </small></p>
			  </div>
			
			<div class="mdl-cell mdl-cell--6-col">
			<h3>Google Tag Manager + Google Analytics</h3>
<ul class="mdl-list teaser-list">
  <li class="mdl-list__item mdl-list__item--three-line">
    <span class="mdl-list__item-primary-content">
      <i id="DL_done" class="material-icons  mdl-list__item-avatar block">block</i>
      <div>DataLayer<br><small>DataLayer HTML-Code Inegration incl. Push Events</small></div>
    </span>
  </li>
  <li class="mdl-list__item mdl-list__item--three-line">
    <span class="mdl-list__item-primary-content">
      <i id="GTM_done" class="material-icons mdl-list__item-avatar block">block</i>
      <div>Google Tag Manager <br><small>GTM JavaScript file loaded and processed.</small></div>
    </span>
  </li>
  <li class="mdl-list__item mdl-list__item--three-line">
    <span class="mdl-list__item-primary-content">
      <i id="GA_done" class="material-icons  mdl-list__item-avatar block">block</i>
      <div>Google Analytics<br><small>Load analytics.js file and send GA-request</small></div>
    </span>
  </li>
</ul>
<pre id="hit_ga_gtm" style="overflow:auto;background-color:#fff;max-height:250px;margin:0 0 0 20px;">
Google Analytics Requests:
</pre>
			
			</div>
			
			<div class="mdl-cell mdl-cell--6-col">
      <h3>Tag Manager Server</h3>
<ul class="mdl-list teaser-list">
<li class="mdl-list__item mdl-list__item--three-line">
  <span class="mdl-list__item-primary-content">
    <i id="DL_TMS" class="material-icons  mdl-list__item-avatar block">block</i>
    <div>DataLayer (same as GTM + GA)<br><small>DataLayer HTML-Code Inegration incl. Push Events</small></div>
  </span>
</li>
  <li class="mdl-list__item mdl-list__item--three-line">
    <span class="mdl-list__item-primary-content">
      <i id="GTM_TMS" class="material-icons mdl-list__item-avatar block">block</i>
      <div>Tag Manager Server<br><small>Tracking configuration via GTM-JSON Import.</small></div>
    </span>
  </li>
  <li class="mdl-list__item mdl-list__item--three-line">
    <span class="mdl-list__item-primary-content">
      <i id="GA_TMS" class="material-icons  mdl-list__item-avatar block">block</i>
      <div>server-side Google Analytics tracking<br><small>All Google Analytics requests are Server 2 Server</small></div>
    </span>
  </li>
</ul>
<pre id="hit_tms" style="overflow:auto;background-color:#fff;max-height:250px;margin:0 0 0 20px;">
server-side Google Analytics Requests:
</pre>		
			</div>
      </div>


        </main>
  
</div>


    <script src="https://code.getmdl.io/1.0.6/material.min.js"></script>
    <script>

      if(window.dataLayer.length > 0){
        document.getElementById("DL_TMS").classList.remove("block");
        document.getElementById("DL_TMS").classList.add("success");
        document.getElementById("DL_TMS").innerText = 'done';
        document.getElementById("DL_done").classList.remove("block");
        document.getElementById("DL_done").classList.add("success");
        document.getElementById("DL_done").innerText = 'done';
      }

    </script>
</body>

</html>
