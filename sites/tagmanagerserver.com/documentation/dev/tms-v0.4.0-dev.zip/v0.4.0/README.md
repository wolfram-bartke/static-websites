# Tag Manager Server
Server-side Google Analytics tracking with the Tag Manager Server: https://www.tagmanagerserver.com

TMS vs. GTM tracking live demo: https://www.tagmanagerserver.com/demo/ *(test with different browser and settings)*

## Table of Contents
- [What is the Tag Manager Server?](#what-is-the-tag-manager-server)
- [Supported tags, trigger and variables](#supported-tags-triggers-and-variables)
  - [Tags](#tags)
  - [Trigger](#trigger)
  - [Variables](#variables)
- [Installation](#installation)
  - [Preparation](#preparation)
  - [Implementation](#implementation)
    - [Subfolder variant](#subfolder-variant)
    - [Subfolder proxy variant](#subfolder-proxy-variant)
    - [Subdomain variant](#subdomain-variant)
 - [Debugging](#debugging)
   - [Troubleshooting your first run](#troubleshooting-your-first-run)
   - [Debug mode](#debug-mode)

## What is the Tag Manager Server?
The Tag Manager Server moves most tracking scripts from the browser to a server. The processing of the DataLayer is the same as Google Tag Manager — of course all e-commerce events are taken into account.

Variables and triggers can be created with the Google Tag Manager as before. GTM container will be exported and imported via JSON-file.

All DataLayer push events are automatically sent to the Tag Manager server, processed there, and sent to Google Analytics via the Measurement Protocol.

<img src="https://github.com/Tag-Manager-Server/tms/blob/master/docs/img/tag-manager-server.png?raw=true" width="50%" />

##  What is the TMS not?
In most cases, this is **no replacement for the Google Tag Manager**.
- the tms only supports the most important Universal Analytics functions of the Google Tag Manager 
   - full list of TMS features: https://www.tagmanagerserver.com/en/#functions
- no third party tags supported
- my recommendation: **track all TMS hits in an additional Google Analytics property**

## So what does the TMS?
The Tag Manager Server provides more accurate web analytics data, with minimal effort.
- bypass AdBlocker, ITP and ETP with server-side tracking
- track more sessions
- **generates much better E-commerce data!** :rocket:

# Supported tags, triggers and variables

## Tags
- Universal Analytics Tag
  - with pageviews and events
  - custom dimensions and metrics
  - Enhanced Ecommerce Tracking
  - overriding setting in tags not supported
*everything else is ignored*

## Trigger
- Types
  - Page View
  - DOM Ready
  - Window Loaded
  - User defined events
- Filters
  - all trigger filters, except the CSS_SELECTOR, are already handled
  - regular expressions are interpreted by PHP, so you must translate all JavaScript RegEx patterns to PHP before exporting the GTM Container
*everything else is ignored*
  
## Variables
- HTTP Referrer
- URL
- Data Layer Variable
- Custom Event
- Google Analytics Settings
- Constant
- RegEx Table (use PHP RegEx patterns!)
- Lookup Table
*everything else is ignored*

# Installation
This Tag Manager Server can implemented in three different ways:
1. **Subfolder**: website or online shop integration
   1. no additional server required
   1. access to first-party cookies via TMS
1. **Subfolder proxy**: for example via htaccess proxy
   1. performance flexibility
   1. centralize TMS tracking for multiple pages on one server
1. **Subdomain**:
   1. performance flexibility
   1. implementation for non PHP pages on another PHP server
   
## Preparation
- Create a new Google Analytics Property for TMS Tracking
- Build a Google Tag Manager Container
   - Import the [/src/GTM-Container/GTM-MIN.json](https://github.com/Tag-Manager-Server/tms/blob/master/src/GTM-Container/GTM-MIN.json), **use your current GTM-container or **build a new one in Google Tag Manager**
   - Set the GA-ID to your new TMS-Property-ID
   - Reduce your container to the currently [supported tags, triggers and variables](#supported-tags-triggers-and-variables)
   - Export this container to JSON-file (e.g. GTM-XXXXXXX.json)
   - Changes to this container must be exported and uploaded again
- Make sure PHP curl requests incl. SSL are executable on your server (e.g. check your PHP configuration with ```phpinfo()```)

## Implementation
1. All files in the subfolder [/src](https://github.com/Tag-Manager-Server/TMS/tree/master/src) are necessary for the implementation of the TMS.
   1. Create a copy of this folder for your project
   1. Google Tag Manager JSON-files are protected by an htaccess file in the subfolder /src/GTM-Container
   1. Move your GTM-XXXXXXX.json file into this protected folder
1. Set your domain configuration in the [config.php](https://github.com/Tag-Manager-Server/tms/blob/master/src/config.php) for your website host
   1. ```$aConfig['www.your-domain.com']['sCookieHost'] = 'your-domain.com';```
   1. ```$aConfig['www.your-domain.com']['sGTM_ContainerFile'] = 'GTM-Container/GTM-XXXXXXX.json';``` (your Google Tag Manager export JSON-file)
1. Upload your 5 files to a subfolder on your tracking server (e.g. your-domain.com/tms )
   1. [tms.js](https://github.com/Tag-Manager-Server/tms/blob/master/src/tms.js) (maybe minify before upload)
   1. [api.php](https://github.com/Tag-Manager-Server/tms/blob/master/src/api.php)
   1. [TMS.php](https://github.com/Tag-Manager-Server/tms/blob/master/src/TMS.php)
   1. [config.php](https://github.com/Tag-Manager-Server/tms/blob/master/src/config.php)
   1. [GTM-Container](https://github.com/Tag-Manager-Server/TMS/tree/master/src/GTM-Container)/GTM-XXXXXXX.json
1. Include the tms.js Script in your HTML-code **before your first dataLayer initialization and GTM integration**
   1. Example: ```<script src="tms/tms.js"></script>```

### Subfolder variant
You are ready to go!

Generate your first page view and check the result in the Real-Time report of your Google Analytics property.

### Subfolder proxy variant
**Alternative implementation to centralize TMS tracking for multiple pages on one server.**

Create a subfolder with this htaccess-proxy-file:
```
RewriteEngine On
RewriteRule ^api.php$ https://your.tracking-domain.com/api.php [P]
RewriteRule ^tms.js$ https://your.tracking-domain.com/tms.js [P]
```
You may need to activate some required Apache modules for mod_proxy.

### Subdomain variant
**Alternative implementation for non PHP pages or for load balancing on another PHP server.**

Include the tms.js Script before your first dataLayer call and GTM integration from your tracking subdomain.

```<script src="https://tracking.your-domain.com/tms.js"></script>```

To set first party cookies from this subdomain, the site or online store may need to send additional header information:
```
access-control-allow-credentials: true
access-control-allow-origin: https://tracking.your-domain.com
```

# Debugging

## Troubleshooting your first run
1. Generate your first page view
1. Check the Real-Time in Google Analytics
1. Make sure that the dataLayer is not reinitialized after the integration of the tms.js
   1. For this reason, use such a template during dataLayer initialization: window.dataLayer = window.dataLayer [];
   1. And then use dataLayer.push calls to extend the DataLayer 
1. Check Browser console messages in your browser DevTools for
   1. JavaScript errors
   1. TMS debug informations (with active debug mode)
1. Check the presence and status code (200) for two requests in the network communication
   1. tms.js
   1. api.php
      1. check the respnse of this XHR request
1. Make sure that your Google Tag Manager export JSON-file is representing a valid JSON syntax
1. Verify the UA-ID in your Google Tag Manager container
1. Make sure you installed the PHP curl module and not to block it in your php.ini (e. g. using disable_functions).
1. Start from the beginning with this test example: [/test/index.php](https://github.com/Tag-Manager-Server/tms/blob/master/test/index.php)
   1. So you can compare the functionality of your Tag Manager Container with the TMS version.


## Debug mode
Activate the browser console messages in [/src/tms.js](https://github.com/Tag-Manager-Server/tms/blob/master/src/tms.js) Script on line 10:

```TMS.debug.mode = 1```

- **Tag Manager Server Input** shows the submitted data from the browser to the TMS API.
- **Tag Manager Server Action** shows the server request of the TMS via the [measurement protocol](https://developers.google.com/analytics/devguides/collection/protocol/v1/parameters) to Google Analytics


### Pageview examle
<img src="https://github.com/Tag-Manager-Server/tms/blob/master/docs/img/debug-console-pageview.png?raw=true" width="100%" />

### E-commerce purchase example
<img src="https://github.com/Tag-Manager-Server/tms/blob/master/docs/img/debug-console-eec-purchase.png?raw=true" width="100%" />
