chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    switch(request.action) {
        case "setIcon":
            if(request.icon){
                chrome.browserAction.setIcon({path: request.icon, tabId:sender.tab.id});
            }
            if(request.hasOwnProperty('text')){
                chrome.browserAction.setBadgeText({text:request.text, tabId:sender.tab.id});
                if(request.hasOwnProperty('textBg')){
                    chrome.browserAction.setBadgeBackgroundColor({color:request.textBg, tabId:sender.tab.id});
                     // [65, 132, 243, 230] blau
                     // [228, 119, 37, 230] orange
                     // [73, 163, 47, 230] grün
                     // [190, 190, 190, 230] grau
                }else{
                    chrome.browserAction.setBadgeBackgroundColor({color:[190, 190, 190, 230], tabId:sender.tab.id});
                }
            }
            
            //sendResponse('from back');
            break;
    }

});

chrome.tabs.onActivated.addListener(function(tabId, changeInfo, tab) {
    chrome.browserAction.setIcon({path: 'icon16g.png'});
    chrome.browserAction.setBadgeText({text:'- : -'});
    chrome.browserAction.setBadgeBackgroundColor({color:[190, 190, 190, 230]});
    //var activeTab = tabId;
    //chrome.tabs.sendMessage(activeTab, {action:"UpdateSetting"});
 });

