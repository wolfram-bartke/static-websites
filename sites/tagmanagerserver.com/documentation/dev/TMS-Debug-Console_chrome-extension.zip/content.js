function UpdateSetting(){
    var oTmsDebugSetting = {};

    oTmsDebugSetting.sAuth = localStorage.getItem("tms_debug_auth");
    oTmsDebugSetting.sError = sessionStorage.getItem("tms_debug_error");
    oTmsDebugSetting.sConsole = localStorage.getItem("tms_debug_console");
    oTmsDebugSetting.sMode = localStorage.getItem("tms_debug_mode");
    oTmsDebugSetting.sPreview = localStorage.getItem("tms_debug_preview");
    oTmsDebugSetting.sPreviewValid = sessionStorage.getItem("tms_debug_preview_valid");
    
    if(oTmsDebugSetting.sAuth){
        chrome.runtime.sendMessage({action: "setIcon", icon: "icon16.png"});
        if(oTmsDebugSetting.sConsole){
            oTmsDebugSetting.iPushCount = sessionStorage.getItem("tms_debug_pushCount");
            oTmsDebugSetting.iTagCount = sessionStorage.getItem("tms_debug_tagCount");
            if(oTmsDebugSetting.sError != 0){
                chrome.runtime.sendMessage({action: "setIcon", text: oTmsDebugSetting.sError, textBg:[255, 0, 0, 230]});
            }else if(!oTmsDebugSetting.hasOwnProperty('sConsole') || oTmsDebugSetting.sConsole == 0){
                chrome.runtime.sendMessage({action: "setIcon", text: "- : -", textBg:[190, 190, 190, 230]});
            }else if(oTmsDebugSetting.sMode == 1 || oTmsDebugSetting.sPreviewValid == 1){
                chrome.runtime.sendMessage({action: "setIcon", text: oTmsDebugSetting.iPushCount+" : "+oTmsDebugSetting.iTagCount, textBg:[228, 119, 37, 230]});
            }else{
                chrome.runtime.sendMessage({action: "setIcon", text: oTmsDebugSetting.iPushCount+" : "+oTmsDebugSetting.iTagCount, textBg:[73, 163, 47, 230]});
            }
            
        }
        setTimeout(UpdateSetting, 1000);
    }else{
        chrome.runtime.sendMessage({action: "setIcon", icon: "icon16g.png"});
    }
    return oTmsDebugSetting;
}
UpdateSetting();


chrome.runtime.onMessage.addListener(
    function(message, sender, sendResponse) {
        switch(message.action) {
            case "getLocalStorage":
                if(message.key){
                    sendResponse(localStorage.getItem(message.key));
                }
            break;

            case "setLocalStorage":
                if(message.key && message.value){
                    localStorage.setItem(message.key, message.value)
                    sendResponse('settings saved');
                }
            break;

            case "getSetting":
                
                var oResponse = {};
                oResponse.sAuth = localStorage.getItem("tms_debug_auth");
                oResponse.sConsole = localStorage.getItem("tms_debug_console");
                oResponse.sMode = localStorage.getItem("tms_debug_mode");
                oResponse.sPreview = localStorage.getItem("tms_debug_preview");
                oResponse.bPreviewValid = sessionStorage.getItem("tms_debug_preview_valid");
                oResponse.sError = sessionStorage.getItem("tms_debug_error");
                oResponse.iPushCount = sessionStorage.getItem("tms_debug_pushCount");
                oResponse.iTagCount = sessionStorage.getItem("tms_debug_tagCount");
                sendResponse(oResponse);
            
            break;

            case "saveSetting":
                localStorage.setItem("tms_debug_auth", message.data.sAuth);
                localStorage.setItem("tms_debug_console", message.data.sConsole);
                localStorage.setItem("tms_debug_mode", message.data.sMode);
                localStorage.setItem("tms_debug_preview", message.data.sPreview);
                window.location.reload();
                sendResponse('settings changed');
            
            break;
                
        }
    }
);